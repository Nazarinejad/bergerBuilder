import React , {Component} from 'react';
import Auxiliary from '../../hoc/Auxiliary/Auxiliary';
import Burger from '../../components/Burger/Burger';
import BuildControls from '../../components/Burger/BuildControls/BuildControls';
import Modal from '../../components/UI/Modal/Modal';
import OrderSummary from '../../components/Burger/OrderSummary/OrderSummary';

const INGREDIENT_PRICES = {
    salad:0.5,
    bacon:0.7,
    cheese:0.4,
    meat:1.3
}

class BurgerBuilder extends Component{
    
    state = {
        ingredients:{
            salad:1,
            bacon:1,
            cheese:1,
            meat:1
        },
        totalPrice: 2.9,
        purchasable : true,
        purchasing : false
    }

    UpdatePurchaseState = (ingredients) => {
        const sum = Object.keys(ingredients)
        .map(igKey => {
            return ingredients[igKey]
        })
        .reduce(( sum , el) => {
            return sum + el;
        } , 0);

        this.setState({purchasable : sum > 0});
    }

    addIngredientsHandler = (ingredientsType) => {

        const prevTotalPrice = this.state.totalPrice;
        const ingredientPrice = INGREDIENT_PRICES[ingredientsType]; 
        const newPrice = prevTotalPrice + ingredientPrice;

        const prevCount = this.state.ingredients[ingredientsType];
        const newCount = prevCount + 1;
        const updatedIngredients = {
            ...this.state.ingredients
        };
        updatedIngredients[ingredientsType] = newCount;

        
        this.setState({
            totalPrice : newPrice,
            ingredients: updatedIngredients
        });

        this.UpdatePurchaseState(updatedIngredients);
    }

    RemoveIngredientsHandler = (ingredientsType) =>{
        const prevCount = this.state.ingredients[ingredientsType];
        if(prevCount <= 0){
            return;
        }
        const newCount = prevCount - 1;
        const updatedIngredients = {
            ...this.state.ingredients
        };
        updatedIngredients[ingredientsType] = newCount;

        const prevTotalPrice = this.state.totalPrice;
        const ingredientPrice = INGREDIENT_PRICES[ingredientsType]; 
        const newPrice = prevTotalPrice - ingredientPrice;
        
        this.setState({
            totalPrice : newPrice,
            ingredients: updatedIngredients
        });
        this.UpdatePurchaseState(updatedIngredients);
        
    }


    PurchaseHandler = () => {
        this.setState({
            purchasing : true
        })
    }

    PurchaseCancelHandler = () =>{
        this.setState({
            purchasing : false
        })
    }

    render(){
        const disabledIngredients = {
            ...this.state.ingredients
        }
        for(let key in disabledIngredients){
            disabledIngredients[key] = disabledIngredients[key] <= 0; // the expression returns true or false so we have all values in boolean
            //(in fact the expresion is a conditional expresion)
        }
        return(
            <Auxiliary>
                <Modal show={this.state.purchasing} cleseModal={this.PurchaseCancelHandler}>
                    <OrderSummary ingredients={this.state.ingredients} />
                </Modal>
                <Burger ingredients={this.state.ingredients}/>
                <BuildControls 
                purchaseable = {this.state.purchasable} 
                price = {this.state.totalPrice}
                disabledIngredients = {disabledIngredients}
                reomoveIngredients = {this.RemoveIngredientsHandler}
                addIngredients = {this.addIngredientsHandler} 
                order = {this.PurchaseHandler}/>
            </Auxiliary>
        )
    };
}

export default BurgerBuilder;